# Servicio Web de Autenticación
## GA7-220501096-AA5-EV01

API REST para registro e inicio de sesión de usuarios, desarrollada con Node.js y Express.

---

## 📋 Descripción

Este proyecto implementa un servicio web de autenticación que permite:
- **Registro de usuarios** con validación y cifrado de contraseñas.
- **Inicio de sesión** con verificación de credenciales y generación de token JWT.
- **Interfaz web** para interactuar con la API visualmente.

---

## 🚀 Instalación y ejecución

### Requisitos
- Node.js v16 o superior
- npm

### Pasos

```bash
# 1. Clonar el repositorio
git clone https://github.com/TU_USUARIO/auth-api-ga7.git

# 2. Entrar a la carpeta del proyecto
cd auth-api-ga7

# 3. Instalar dependencias
npm install

# 4. Iniciar el servidor
npm start
```

El servidor quedará disponible en: **http://localhost:3000**

---

## 📡 Endpoints de la API

| Método | Ruta | Descripción |
|--------|------|-------------|
| `POST` | `/api/registro` | Registrar un nuevo usuario |
| `POST` | `/api/login` | Iniciar sesión |
| `GET` | `/api/usuarios` | Listar usuarios registrados |

---

## 📨 Ejemplos de uso

### Registro de usuario

**Request:**
```http
POST /api/registro
Content-Type: application/json

{
  "usuario": "juanperez",
  "contrasena": "miClave123"
}
```

**Respuesta exitosa:**
```json
{
  "exito": true,
  "mensaje": "Registro exitoso. ¡Bienvenido al sistema!",
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "usuario": {
    "id": 1,
    "usuario": "juanperez",
    "fechaRegistro": "2024-01-01T00:00:00.000Z"
  }
}
```

---

### Inicio de sesión

**Request:**
```http
POST /api/login
Content-Type: application/json

{
  "usuario": "juanperez",
  "contrasena": "miClave123"
}
```

**Respuesta exitosa:**
```json
{
  "exito": true,
  "mensaje": "Autenticación satisfactoria. ¡Bienvenido de vuelta!",
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

**Respuesta con error de autenticación:**
```json
{
  "exito": false,
  "mensaje": "Error en la autenticación: usuario o contraseña incorrectos"
}
```

---

## 🛠 Tecnologías utilizadas

| Tecnología | Uso |
|-----------|-----|
| **Node.js** | Entorno de ejecución |
| **Express** | Framework web |
| **bcryptjs** | Cifrado de contraseñas |
| **jsonwebtoken** | Generación de tokens JWT |

---

## 📁 Estructura del proyecto

```
auth-api-ga7/
├── src/
│   └── server.js       # Servidor principal con todos los endpoints
├── public/
│   └── index.html      # Interfaz web de prueba
├── package.json        # Configuración del proyecto y dependencias
├── .gitignore          # Archivos ignorados por Git
└── README.md           # Documentación del proyecto
```

---

## 🔗 Repositorio

**URL del repositorio:** https://github.com/TU_USUARIO/auth-api-ga7

> ⚠️ Reemplaza `TU_USUARIO` con tu nombre de usuario de GitHub.

---

## 📌 Instrucciones para subir a GitHub

```bash
# 1. Inicializar repositorio local
git init

# 2. Agregar todos los archivos
git add .

# 3. Hacer el primer commit
git commit -m "feat: servicio web de autenticación AA5-EV01"

# 4. Agregar el repositorio remoto
git remote add origin https://github.com/TU_USUARIO/auth-api-ga7.git

# 5. Subir el código
git push -u origin main
```

---

*Evidencia: GA7-220501096-AA5-EV01 - Diseño y desarrollo de servicios web*

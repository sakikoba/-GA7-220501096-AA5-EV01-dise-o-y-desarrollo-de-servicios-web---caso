/**
 * ============================================================
 * SERVICIO WEB DE AUTENTICACIÓN - GA7-220501096-AA5-EV01
 * ============================================================
 * Descripción: API REST para registro e inicio de sesión de usuarios.
 * Tecnología: Node.js con Express
 * Autor: Evidencia AA5-EV01
 * ============================================================
 */

const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const path = require('path');

// Inicialización de la aplicación Express
const app = express();
const PORT = 3000;

// Clave secreta para firmar los tokens JWT
// En producción, esta clave debe estar en variables de entorno
const JWT_SECRET = 'clave_secreta_jwt_2024';

// Número de rondas para el hash de contraseñas (mayor = más seguro pero más lento)
const SALT_ROUNDS = 10;

/**
 * Base de datos en memoria para almacenar usuarios.
 * En un entorno de producción, esto se reemplazaría por una base de datos real
 * como MySQL, PostgreSQL o MongoDB.
 */
const usuarios = [];

// ============================================================
// MIDDLEWARES
// ============================================================

// Middleware para parsear el cuerpo de las solicitudes en formato JSON
app.use(express.json());

// Middleware para servir archivos estáticos desde la carpeta 'public'
app.use(express.static(path.join(__dirname, '../public')));

// Middleware para registrar todas las solicitudes entrantes (logging)
app.use((req, res, next) => {
  const fecha = new Date().toISOString();
  console.log(`[${fecha}] ${req.method} ${req.url}`);
  next();
});

// ============================================================
// RUTAS DE LA API
// ============================================================

/**
 * GET /
 * Ruta principal - Sirve la interfaz web de la aplicación
 */
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/index.html'));
});

/**
 * POST /api/registro
 * Endpoint para registrar un nuevo usuario en el sistema.
 *
 * @body {string} usuario - Nombre de usuario único
 * @body {string} contrasena - Contraseña del usuario (mínimo 6 caracteres)
 *
 * @returns {200} Mensaje de éxito con token JWT si el registro fue exitoso
 * @returns {400} Error si los datos son inválidos o el usuario ya existe
 * @returns {500} Error interno del servidor
 */
app.post('/api/registro', async (req, res) => {
  try {
    // Extraer usuario y contraseña del cuerpo de la solicitud
    const { usuario, contrasena } = req.body;

    // Validar que se proporcionaron los campos requeridos
    if (!usuario || !contrasena) {
      return res.status(400).json({
        exito: false,
        mensaje: 'El usuario y la contraseña son obligatorios'
      });
    }

    // Validar que el nombre de usuario tenga al menos 3 caracteres
    if (usuario.length < 3) {
      return res.status(400).json({
        exito: false,
        mensaje: 'El nombre de usuario debe tener al menos 3 caracteres'
      });
    }

    // Validar que la contraseña tenga al menos 6 caracteres
    if (contrasena.length < 6) {
      return res.status(400).json({
        exito: false,
        mensaje: 'La contraseña debe tener al menos 6 caracteres'
      });
    }

    // Verificar si el usuario ya existe en la base de datos
    const usuarioExistente = usuarios.find(u => u.usuario === usuario);
    if (usuarioExistente) {
      return res.status(400).json({
        exito: false,
        mensaje: 'El nombre de usuario ya está en uso. Por favor elige otro.'
      });
    }

    // Cifrar la contraseña usando bcrypt antes de almacenarla
    // Nunca se debe almacenar la contraseña en texto plano
    const contrasenaHasheada = await bcrypt.hash(contrasena, SALT_ROUNDS);

    // Crear el objeto del nuevo usuario
    const nuevoUsuario = {
      id: usuarios.length + 1,
      usuario: usuario,
      contrasena: contrasenaHasheada,
      fechaRegistro: new Date().toISOString()
    };

    // Agregar el nuevo usuario a la base de datos en memoria
    usuarios.push(nuevoUsuario);

    // Generar un token JWT para el usuario recién registrado
    // El token contiene el ID y nombre de usuario, y expira en 24 horas
    const token = jwt.sign(
      { id: nuevoUsuario.id, usuario: nuevoUsuario.usuario },
      JWT_SECRET,
      { expiresIn: '24h' }
    );

    // Responder con éxito, incluyendo el token y datos básicos del usuario
    return res.status(200).json({
      exito: true,
      mensaje: 'Registro exitoso. ¡Bienvenido al sistema!',
      token: token,
      usuario: {
        id: nuevoUsuario.id,
        usuario: nuevoUsuario.usuario,
        fechaRegistro: nuevoUsuario.fechaRegistro
      }
    });

  } catch (error) {
    // Manejo de errores internos del servidor
    console.error('Error en el registro:', error);
    return res.status(500).json({
      exito: false,
      mensaje: 'Error interno del servidor. Intenta de nuevo más tarde.'
    });
  }
});

/**
 * POST /api/login
 * Endpoint para iniciar sesión con un usuario existente.
 *
 * @body {string} usuario - Nombre de usuario registrado
 * @body {string} contrasena - Contraseña del usuario
 *
 * @returns {200} Mensaje de autenticación satisfactoria con token JWT
 * @returns {400} Error si los campos están vacíos
 * @returns {401} Error de autenticación si las credenciales son incorrectas
 * @returns {500} Error interno del servidor
 */
app.post('/api/login', async (req, res) => {
  try {
    // Extraer las credenciales del cuerpo de la solicitud
    const { usuario, contrasena } = req.body;

    // Validar que se proporcionaron los campos requeridos
    if (!usuario || !contrasena) {
      return res.status(400).json({
        exito: false,
        mensaje: 'El usuario y la contraseña son obligatorios'
      });
    }

    // Buscar el usuario en la base de datos por su nombre de usuario
    const usuarioEncontrado = usuarios.find(u => u.usuario === usuario);

    // Si el usuario no existe, retornar error de autenticación
    // Se usa el mismo mensaje para no revelar si el usuario existe o no (seguridad)
    if (!usuarioEncontrado) {
      return res.status(401).json({
        exito: false,
        mensaje: 'Error en la autenticación: usuario o contraseña incorrectos'
      });
    }

    // Comparar la contraseña proporcionada con el hash almacenado
    // bcrypt.compare() maneja la comparación de forma segura
    const contrasenaCorrecta = await bcrypt.compare(contrasena, usuarioEncontrado.contrasena);

    // Si la contraseña no coincide, retornar error de autenticación
    if (!contrasenaCorrecta) {
      return res.status(401).json({
        exito: false,
        mensaje: 'Error en la autenticación: usuario o contraseña incorrectos'
      });
    }

    // Generar un nuevo token JWT para la sesión del usuario
    // El token expira en 24 horas
    const token = jwt.sign(
      { id: usuarioEncontrado.id, usuario: usuarioEncontrado.usuario },
      JWT_SECRET,
      { expiresIn: '24h' }
    );

    // Responder con mensaje de autenticación satisfactoria y el token
    return res.status(200).json({
      exito: true,
      mensaje: 'Autenticación satisfactoria. ¡Bienvenido de vuelta!',
      token: token,
      usuario: {
        id: usuarioEncontrado.id,
        usuario: usuarioEncontrado.usuario,
        fechaRegistro: usuarioEncontrado.fechaRegistro
      }
    });

  } catch (error) {
    // Manejo de errores internos del servidor
    console.error('Error en el login:', error);
    return res.status(500).json({
      exito: false,
      mensaje: 'Error interno del servidor. Intenta de nuevo más tarde.'
    });
  }
});

/**
 * GET /api/usuarios
 * Endpoint para listar todos los usuarios registrados (sin contraseñas).
 * En producción, este endpoint debería estar protegido por autenticación.
 *
 * @returns {200} Lista de usuarios registrados
 */
app.get('/api/usuarios', (req, res) => {
  // Retornar lista de usuarios sin incluir las contraseñas hasheadas
  const usuariosSeguros = usuarios.map(u => ({
    id: u.id,
    usuario: u.usuario,
    fechaRegistro: u.fechaRegistro
  }));

  return res.status(200).json({
    exito: true,
    total: usuariosSeguros.length,
    usuarios: usuariosSeguros
  });
});

// ============================================================
// MANEJO DE RUTAS NO ENCONTRADAS
// ============================================================

/**
 * Middleware para manejar rutas que no existen (404)
 */
app.use((req, res) => {
  return res.status(404).json({
    exito: false,
    mensaje: 'Ruta no encontrada'
  });
});

// ============================================================
// INICIO DEL SERVIDOR
// ============================================================

/**
 * Iniciar el servidor en el puerto especificado
 */
app.listen(PORT, () => {
  console.log('============================================================');
  console.log('  SERVICIO WEB DE AUTENTICACIÓN - GA7-220501096-AA5-EV01');
  console.log('============================================================');
  console.log(`  Servidor ejecutándose en: http://localhost:${PORT}`);
  console.log(`  Endpoints disponibles:`);
  console.log(`    POST /api/registro  - Registrar nuevo usuario`);
  console.log(`    POST /api/login     - Iniciar sesión`);
  console.log(`    GET  /api/usuarios  - Listar usuarios`);
  console.log('============================================================');
});

// Exportar la app para pruebas unitarias
module.exports = app;
